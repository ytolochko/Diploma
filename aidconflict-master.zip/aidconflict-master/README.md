# aidconflict
International Donors and Local Armed Groups: Understanding the Subnational Effect of Aid on Conflict
